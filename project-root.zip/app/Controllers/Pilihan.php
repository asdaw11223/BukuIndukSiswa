<?php

namespace App\Controllers;

class Pilihan extends BaseController
{
    public function index()
    {
        return view('rapor/pilihan');
    }
}
