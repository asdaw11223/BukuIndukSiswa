<div class="footer">
    <span class="text">Copyright © 2022 SMK Pasundan Rancaekek. All Rights Reserved</span>
</div>